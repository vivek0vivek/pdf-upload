import formidable from 'formidable';
import fs from 'fs';
import path from 'path';

export const config = {
  api: {
    bodyParser: false, // Disable Next.js body parser to handle file streams
  },
};

export default function handler(req, res) {
  if (req.method === 'POST') {
    const form = formidable({
      uploadDir: path.join(process.cwd(), 'public/uploads'),
      keepExtensions: true, // Ensure the file extension is kept
      filename: (name, ext, path) => {
        // Save the file with its original name
        return name + ext; // You can also use a safer version of the name here if necessary
      }
    });

    form.parse(req, (err, fields, files) => {
      if (err) {
        return res.status(500).json({ error: 'File upload failed', message: err.message });
      }

      // Access the uploaded file
      const uploadedFile = files.file[0];
      const filePath = path.join(process.cwd(), 'public/uploads', uploadedFile.newFilename);

      res.status(200).json({ message: 'File uploaded successfully', filePath });
    });
  } else {
    res.setHeader('Allow', ['POST']);
    res.status(405).end(`Method ${req.method} Not Allowed`);
  }
}
